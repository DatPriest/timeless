# sbox-minimal

![Screenshot](https://files.facepunch.com/garry/8fc638dc-2c62-4ed6-b20a-69c2c5342a9c.jpg)

 Minimal gamemode for s&box.
 
 # Installing
 
 Download as a zip and put the minimum folder in your addons/ folder. It should show up in the menu allowing you to make a new game.
 
 # Editing
 
 Run the game to generate the project and open s&box.sln.
 
 Editing the .cs, .html, .scss files should reflect their changes in game in realtime.
